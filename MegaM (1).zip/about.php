  <!-- About Section -->
  <section id="buy">
  </section>
  <section class="page-section bg-primary first" id="about">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 text-center">
          <h2 class="text-white mt-0">We've got what you need!</h2>
          <hr class="divider light my-4">
          <p class="text-white-50 mb-4">Etiam ac volutpat erat. Etiam malesuada felis sed cursus luctus. Duis ex nisl, ullamcorper non quam nec, condimentum dapibus neque. Phasellus hendrerit ultricies augue, at porttitor nisl commodo cursus. Fusce tempor egestas massa, at eleifend lectus fermentum sit amet. </p>
          <a class="btn btn-light btn-xl js-scroll-trigger" href="#buy" onclick="ShowForm()">Get Started!</a>
        </div>
      </div>
    </div>
  </section>