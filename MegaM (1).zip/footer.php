  <!-- Footer -->
  <footer class="bg-primary py-5">
    <div class="container">
      <div class="small text-center text-white">Copyright &copy; 2019 - Mega M</div>
    </div>
  </footer>