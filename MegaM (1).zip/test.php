<?php
//Shipping & Billing info
$name = $_POST["First_name"];
$surname = $_POST["Last_name"];
$company = $_POST["Organization"];
$street = $_POST["Address"];
$number = $_POST["St_number"];
$address2 = $_POST["Address_2"];
$zip = $_POST["Zip_code"];
$city = $_POST["City"];
$country = $_POST["Country"];
//Purchase info
$years = $_POST["Years"];
$data = $_POST["Data"];
$sms = $_POST["SMS"];
$quantity = $_POST["Quantity"];
$price = $_POST["Price"];
//Card info
$cname = $_POST["Card_name"];
$cnum = $_POST["Card_num"];
$expmonth = $_POST["Exp_month"];
$expyear = $_POST["Exp_year"];
$cvv = $_POST["CVV"];

echo $name." ".$surname." ".$company." ".$street." ".$number." ".$address2." ".$zip." ".$city." ".$country."\n".$years." ".$data." ".$sms." ".$quantity." ".$price."\n".$cname." ".$cnum." ".$expmonth." ".$expyear." ".$cvv;
exit;
?>